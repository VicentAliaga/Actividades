package com.dam.Ejercicio7;

import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        /* Modifica el programa anterior per tal que admeta com a paràmetres d’entrada un nombre
        qualsevol d’extensions, tornant després per pantalla tots els fitxers del directori que tinguen
        alguna de les extensions indicades.*/

        Scanner scan = new Scanner(System.in);
        String directorio;
        String extension;
        ArrayList<String> extensiones = new ArrayList<>();
        int salir = 1;

        System.out.println("Introduce un directorio: ");
        directorio = scan.nextLine();

        while (salir != 0) {
            System.out.println("Introduce una extensión:");
            extension = scan.next();
            extensiones.add(extension);

            System.out.println("Pulsa 0 para salir, cualquier otro número para continuar:");
            salir = scan.nextInt();
        }

        File file = new File(directorio);

        if (!file.isDirectory()) {
            System.out.println("El directorio introducido no es válido.");
        } else {
            String[] lista = file.list();

            if (lista == null || lista.length == 0) {
                System.out.println("El directorio está vacío o no se puede leer.");
            } else {
                System.out.println("Archivos que coinciden con las extensiones indicadas:");

                for (String nombreFichero : lista) {
                    for (String ext : extensiones) {
                        if (nombreFichero.endsWith(ext)) {
                            System.out.println(nombreFichero);
                            break;
                        }
                    }
                }
            }
        }
        scan.close();
    }
}

