package com.dam.Ejercicio8;
import java.io.*;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
    	Scanner scan = new Scanner(System.in);
    	String rutaOriginal;
    	
    	System.out.println("Introduce la ruta del archivo: ");
    	rutaOriginal = scan.nextLine();
    	
        File archivoOriginal = new File(rutaOriginal);

        if (!archivoOriginal.exists()) {
            System.out.println("El archivo no existe. Por favor, verifica la ruta.");
            return;
        }

        String nombreArchivoCopia = archivoOriginal.getName().replace(".", "_copia.");
        File archivoCopia = new File(archivoOriginal.getParent(), nombreArchivoCopia);

        try (BufferedReader br = new BufferedReader(new FileReader(archivoOriginal));
             BufferedWriter bw = new BufferedWriter(new FileWriter(archivoCopia))) {

            String linea;
            while ((linea = br.readLine()) != null) {
                bw.write(linea);
                bw.newLine();
            }

            System.out.println("Archivo copiado con éxito: " + archivoCopia.getAbsolutePath());

        } catch (IOException e) {
            System.out.println("Ocurrió un error al copiar el archivo: " + e.getMessage());
            return;
        }

        if (archivoOriginal.delete()) {
            System.out.println("Archivo original borrado con éxito: " + archivoOriginal.getAbsolutePath());
        } else {
            System.out.println("No se pudo borrar el archivo original.");
        }
    }
}

