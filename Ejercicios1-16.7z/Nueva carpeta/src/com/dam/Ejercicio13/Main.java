package com.dam.Ejercicio13;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		String fichero;
		int velocidad;
		
		System.out.println("Introduce el fichero");
		fichero = scan.nextLine();
		
		System.out.println("Introduce la velocidad que quieres que se muestre");
		velocidad = scan.nextInt();
		
		try {
			BufferedReader br = new BufferedReader(new FileReader(fichero));
			
			String linea = br.readLine();
			
			while (linea != null) {
				System.out.println(linea);
				linea = br.readLine();
				Thread.sleep(velocidad);
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO: handle exception
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
