package com.dam.Ejercicio14;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
        String fichero;
        String fichero2;
        
        System.out.println("Introduce el fichero que quieres copiar: ");
        fichero = scan.nextLine();
        
        System.out.println("Introduce el fichero donde lo quieres copiar: ");
        fichero2 = scan.nextLine();
        
        try (BufferedReader br = new BufferedReader(new FileReader(fichero));
             BufferedWriter bw = new BufferedWriter(new FileWriter(fichero2))) {
            
            String linea = br.readLine();
            
            while (linea != null) {
                bw.write(linea); 
                bw.newLine();
                linea = br.readLine();
            }
            
            System.out.println("El archivo ha sido copiado con éxito.");
            
        } catch (IOException e) {
            System.out.println("Ocurrió un error al copiar el archivo: " + e.getMessage());
            e.printStackTrace();
        }
		

	}

}
