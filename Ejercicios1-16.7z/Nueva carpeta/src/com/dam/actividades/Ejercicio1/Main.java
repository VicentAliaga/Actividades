package com.dam.actividades.Ejercicio1;

import java.io.File;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		String directorio;
		
		System.out.println("Introduce un directorio: ");
		directorio = scan.nextLine();
		
		File file = new File(directorio);
		
		System.out.println(file);
	}

}
