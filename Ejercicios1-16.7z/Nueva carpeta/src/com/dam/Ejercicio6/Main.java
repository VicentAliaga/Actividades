package com.dam.Ejercicio6;

import java.io.File;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		String directorio;
		String extension;
		
		
		System.out.println("Introduce un directorio: ");
		directorio = scan.nextLine();
		
		System.out.println("Introduce una extensión: ");
		extension = scan.nextLine();
		
		File file = new File(directorio);
		
		String[] lista = file.list();
		
		if (extension == null) {
			for (int i = 0 ; i<lista.length ; i++) {
				System.out.println(lista[i]);
			}
		} else {
			for (int i = 0 ; i<lista.length ; i++) {
				if(lista[i].endsWith(extension)) {
					System.out.println(lista[i]);
				}
			}
		}
	}

}
