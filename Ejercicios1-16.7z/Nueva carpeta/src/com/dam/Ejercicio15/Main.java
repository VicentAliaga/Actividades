package com.dam.Ejercicio15;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		ArrayList<String> valores = new ArrayList<String>();
		String dato;
		String fichero = "C:\\Users\\Vicent AG\\Documents\\Clase\\DAM2\\AccesoADatos\\FicheroPrueba\\FicheroSi.txt";
		
		while (true) {
			System.out.println("Introduce un valor, escribe exit para salir");
			dato = scan.nextLine();
			
			if (dato.equals("exit")) {
                break;
            }
			
			valores.add(dato);
		}
		
	
		try (BufferedWriter bw = new BufferedWriter(new FileWriter(fichero));){
		
			for (String palabras : valores) {
				bw.write(palabras);
				bw.newLine();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("Todo creado correctamente.");
	}

}
