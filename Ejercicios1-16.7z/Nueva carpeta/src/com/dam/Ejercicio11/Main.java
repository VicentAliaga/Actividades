package com.dam.Ejercicio11;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		String filchero;
		int contador = 0;
		
		System.out.println("Introduce el fichero");
		filchero = scan.nextLine();
		
		try {
			FileReader file = new FileReader(filchero);
			
			int valor = file.read();
			
			while (valor != -1) {
				System.out.print( (char) valor);
				valor = file.read();
				contador = contador + 1;
				if (contador == 4) {
					System.out.println("\nPulsa enter para continuar....");
					scan.nextLine();
					contador = 0;
				}
			}
		} catch (FileNotFoundException e) {
            System.out.println("El archivo no se encontró.");
        } catch (IOException e) {
            System.out.println("Ocurrió un error al leer el archivo.");
            e.printStackTrace();
        }

	}

}
