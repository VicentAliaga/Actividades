package com.dam.Ejercicio5;


import java.io.File;
import java.util.Scanner;
import java.util.logging.Filter;

public class Main {

	public static void main(String[] args) {
		/* Realitza un programa que reba com a paràmetres d’entrada un directori i una extensió de
		fitxer (por exemple .txt) i torne per pantalla tots els fitxers del directori que complisquen el
		criteri.*/
		
		Scanner scan = new Scanner(System.in);
		String directorio;
		String extension;
		
		
		System.out.println("Introduce un directorio: ");
		directorio = scan.nextLine();
		
		System.out.println("Introduce una extensión: ");
		extension = scan.nextLine();
		
		File file = new File(directorio);
		
		String[] lista = file.list();
		
		for (int i = 0 ; i<lista.length ; i++) {
			if(lista[i].endsWith(extension)) {
				System.out.println(lista[i]);
			}
		}
	}

}
