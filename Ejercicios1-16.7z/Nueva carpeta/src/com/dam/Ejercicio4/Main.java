package com.dam.Ejercicio4;

import java.io.File;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		String directorio;
		
		System.out.println("Introduce un directorio: ");
		directorio = scan.nextLine();
		
		File file = new File(directorio);
		String[] lista = file.list();
		
		System.out.println("Se puede leer: " + file.canRead());
		System.out.println("Nombre directorio: " + file.getName());
		System.out.println("Ruta absoluta: " + file.getAbsoluteFile());
		System.out.println("Ruta relativa: " + file.getPath());
		
		System.out.println("Ficheros:");
		for (int i = 0 ; i < lista.length ; i++) {
			System.out.println("- " + lista[i]);
		}
		
		if (file.exists()) {
			System.out.println("Existe");
		} else {
			System.out.println("No existe");
		}

	}

}
