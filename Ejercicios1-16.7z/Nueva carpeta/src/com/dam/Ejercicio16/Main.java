package com.dam.Ejercicio16;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
Scanner scan = new Scanner(System.in);
		
		ArrayList<String> valores = new ArrayList<String>();
		String dato;
		
		LocalDateTime ahora = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss");
        String fechaHora = ahora.format(formatter);
        
		String fichero = "C:\\Users\\Vicent AG\\Documents\\Clase\\DAM2\\AccesoADatos\\FicheroPrueba\\Fichero_" + fechaHora + ".txt";
		
		while (true) {
			System.out.println("Introduce un valor, escribe exit para salir");
			dato = scan.nextLine();
			
			if (dato.equals("exit")) {
                break;
            }
			
			valores.add(dato);
		}
		
	
		try (BufferedWriter bw = new BufferedWriter(new FileWriter(fichero));){
		
			for (String palabras : valores) {
			bw.write(palabras);
			bw.newLine();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("Todo creado correctamente.");

	}

}
