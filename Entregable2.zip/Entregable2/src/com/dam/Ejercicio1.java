package com.dam;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Scanner;

public class Ejercicio1 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		String dir = "C:\\Users\\Vicent AG\\Desktop\\DirectorioActividad";
		File file = new File(dir);
		int elec;
		
		System.out.println("Elige una opción");
		elec = scan.nextInt();
		switch (elec) {
		case 1:
			getInfo(file);
			break;
		case 2:
			crearCarpeta(file);
			break;
		case 3:
			crearDirectorio(file);
			break;
		case 4:
			eliminar(file);
			break;
		}
	}
	
	public static void getInfo(File file) {
		
		//Nombre
		System.out.println("Nombre: " + file.getName());
		
		//Tipus
		if (file.isFile()) {
			System.out.println("La ruta introducida es un archivo");
		}
		if (file.isDirectory()) {
			System.out.println("La ruta introducida es una carpeta");
		}
		
		//Ubicación
		System.out.println("La ubicación del archivo es: " + file.getAbsolutePath());
		
		//FechaModificación
		SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        System.out.println("Última modificación: " + formato.format(file.lastModified()));
		
        //Archivo Oculto?
        if (file.isHidden() == true) {
        	System.out.println("Es un archivo oculto");
        } else {
        	System.out.println("No es un archivo oculto");
        }
        
        if (file.isFile()) {
            // Si es un archivo, mostrar el tamaño en bytes
            System.out.println("Tamaño: " + file.length() + " bytes");
        } else if (file.isDirectory()) {
            // Si es un directorio, mostrar el número de elementos que contiene
            File[] files = file.listFiles();
            if (files != null) {
                System.out.println("Número de elementos: " + files.length);
            }
        }
        
     // Mostrar espacio libre, espacio usable y espacio total
        System.out.println("Espacio libre: " + file.getFreeSpace() + " bytes");
        System.out.println("Espacio disponible: " + file.getUsableSpace() + " bytes");
        System.out.println("Espacio total: " + file.getTotalSpace() + " bytes");
	}
	
	public static void crearCarpeta(File file) {
		Scanner scan = new Scanner(System.in);
		String nombre;
		
		if (!file.exists()) {
            System.out.println("la carpeta no existe.");
            return;
        }
		
		System.out.println("ahora dime el nombre");
		nombre = scan.next();
		
		File nuevaCarpeta = new File(file,nombre);
		
		if (nuevaCarpeta.exists()) {
			System.out.println("La carpeta ya existe");
		} else {
			nuevaCarpeta.mkdir();
			System.out.println("he creado la carpeta");
		}
	}
	
	public static void crearDirectorio(File file) {
		Scanner scan = new Scanner(System.in);
		String nombre;
		
		if (!file.exists()) {
            System.out.println("El directorio no existe.");
            return;
        }
		
		
		System.out.println("ahora dime el nombre");
		nombre = scan.next();
		
		File nuevoFichero = new File(file, nombre);
		
		try {
			if (nuevoFichero.createNewFile()) {
			    System.out.println("Fichero creado exitosamente");
			} else {
			    System.out.println("No se pudo crear el fichero.");
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void eliminar(File file) {
	    if (file.isDirectory()) {
	        for (File archivo : file.listFiles()) {
	            eliminar(archivo);
	        }
	    }

	    if (file.delete()) {
	        System.out.println("Eliminado: " + file.getAbsolutePath());
	    } else {
	        System.out.println("No se pudo eliminar: " + file.getAbsolutePath());
	    }
	
	}
	
	 

}
