package com.actividades1;

import java.io.File;

public class Ejercicio1 {

	public static void main(String[] args) {
		File file = new File("C:\\Users\\Vicent AG\\Documents\\Clase\\DAM1\\Bases de Datos");
		
		System.out.println(file.getName());
	}

}
