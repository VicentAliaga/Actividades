package com.actividades1.Ejercicio7;

import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;

import com.actividades1.Ejercicio5.Filter;

public class Ejercicio7 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);

        System.out.println("Introdueix la ruta del directorio:");
        String ruta = scan.nextLine();
        File directorio = new File(ruta);
        
        String[] extension;
        String salir = "";
        int contador = 0;
        do {
        	
        	System.out.println("Introduce la extensión del fichero");
        	extension[contador] = scan.next();
        
        	System.out.println("Ya estan todas las extensiones que quieres comprobar? ");
        	salir = scan.next();
        
        } while (salir != "S");
        
        for (int i=0 ; i<extension.length ; i++) {
        	System.out.println(extension[i]);
        }

        //Filter filtro = new Filter(extension);
        //File[] archivos;
        
        
		/*
		 * if (directorio.exists()) { if (extension != null) { archivos =
		 * directorio.listFiles(filtro); for (File archivo : archivos) {
		 * System.out.println(archivo.getName()); } } else { archivos =
		 * directorio.listFiles(); for (File archivo : archivos) {
		 * System.out.println(archivo.getName()); } }
		 * 
		 * 
		 * } else { System.out.println("El directorio no existe"); }
		 */
	}

}
