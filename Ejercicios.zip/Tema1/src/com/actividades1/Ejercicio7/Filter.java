package com.actividades1.Ejercicio7;

import java.io.File;

public class Filter {
	String extension;


	public Filter(String filtro) {
		this.extension = filtro;
	}

	public boolean accept(File dir, String name) {
		// TODO Auto-generated method stub
		return name.endsWith(extension);
	}
}
