package com.actividades1.Ejercicio5;

import java.io.File;
import java.io.FilenameFilter;

public class Filter implements FilenameFilter{
	
	String extension;


	public Filter(String filtro) {
		this.extension = filtro;
	}

	@Override
	public boolean accept(File dir, String name) {
		// TODO Auto-generated method stub
		return name.endsWith(extension);
	}
}
