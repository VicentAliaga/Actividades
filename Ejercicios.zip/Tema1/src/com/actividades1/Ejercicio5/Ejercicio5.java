package com.actividades1.Ejercicio5;

import java.io.File;
import java.util.Scanner;

public class Ejercicio5{

	public static void main(String[] args) {
		  	Scanner scan = new Scanner(System.in);

	        System.out.println("Introdueix la ruta del directorio:");
	        String ruta = scan.nextLine();
	        File directorio = new File(ruta);
	        
	        System.out.println("Introduce la extensión del fichero");
	        String extension = scan.nextLine();

	        Filter filtro = new Filter(extension);
	        if (directorio.exists()) {
	        	File[] archivos = directorio.listFiles(filtro);
	        	for (File archivo : archivos) {
					System.out.println(archivo.getName());
				}
	        } else {
	        	System.out.println("El directorio no existe");
	        }

	        
	}

}
