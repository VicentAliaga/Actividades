package com.actividades1;

import java.io.File;

public class Ejercicio3 {

	public static void main(String[] args) {
		File file = new File("C:\\Users\\Vicent AG\\Documents\\Clase\\DAM1\\Bases de Datos");
		String[] lista = file.list();
		
		System.out.println("Se puede leer: " + file.canRead());
		System.out.println("Nombre directorio: " + file.getName());
		System.out.println("Ruta absoluta: " + file.getAbsoluteFile());
		System.out.println("Ruta relativa: " + file.getPath());
		
		System.out.println("Ficheros:");
		
		for (int i = 0 ; i < lista.length ; i++) {
			System.out.println("- " + lista[i]);
		}
		
		System.out.println("\nExiste: " + file.exists());
	}

}
