package com.actividades1;

import java.io.File;

public class Ejercicio4 {
	public static void main(String[] args) {
		File file = new File("C:\\Users\\Vicent AG\\Documents\\Clase\\DAM1\\Bases de Datos");
		String[] lista = file.list();
		
		if (file.exists() == true) {
			System.out.println("Existe");
		} else {
			System.out.println("No existe");
		}
	}
}
