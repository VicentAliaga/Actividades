package com.dam.Entregable;

public class Main {

	public static void main(String[] args) {
		Modelo m = new Modelo();
		
		m.sayHello();
		m.mostarNumeros();
		
		int[] numeros = new int[5];
		numeros[0] = 5;
		numeros[1] = 4;
		numeros[2] = 3;
		numeros[3] = 2;
		numeros[4] = 1;
		m.companeros(numeros);
	}

}
