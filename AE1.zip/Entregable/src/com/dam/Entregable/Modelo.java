package com.dam.Entregable;

import java.util.ArrayList;
import java.util.Scanner;

public class Modelo {
	Scanner scan = new Scanner(System.in);
	public void sayHello() {
		System.out.println("Hola Mundo");
	}
	
	public void mostarNumeros() {
		int num1;
		int num2;
		int suma = 0;
		
		System.out.println("Introduce un número");
		num1 = scan.nextInt();
		
		System.out.println("Introduce otro número");
		num2 = scan.nextInt();
		// Si solo se pueda dividir entre 1 y entre el para que de 0
		for (int i=num1; i<=num2; i++) {
			/*
			 * if (i%1 == 0 && i%i == 0) { System.out.println(i + " es primo"); } if (i%1 !=
			 * 0 && i%i != 0) { System.out.println(i + "no es primo"); }
			 */
			for (int n = 1 ; n<=100 ; n++) {
				if ((i%n == 0 && n != 1) && (i%n == 0 && n != i)) { 
					  //System.out.println(i +"es primo"); 
				} else {
					//System.out.println(i + "no es");
				}
				 
			}
			suma = suma + i;
		}
		System.out.println("La suma de todos los números es " + suma);
	}
	
	public void companeros(int[] numeros) {
		ArrayList<String> compañeros = new ArrayList<String>();
		compañeros.add("Vicent");
		compañeros.add("Xavi");
		compañeros.add("Pablo");
		compañeros.add("Carlos");
		compañeros.add("Javier");
		compañeros.add("Maria");
		
		int numeroMayor = 0;
		System.out.println("Compañeros que coinciden con posicíon números array:");
		for (int i=0 ;i<numeros.length ; i++) {
			System.out.println(numeros[i] +" = "+  compañeros.get(numeros[i]));
		}
		
		for (int i = 0; i< numeros.length; i++) {
			if (numeros[i] > numeroMayor) {
				numeroMayor = numeros[i];
			}
		}		
		System.out.println("El número más grande de la lista que me has pasado es: " + numeroMayor);
	}
}
