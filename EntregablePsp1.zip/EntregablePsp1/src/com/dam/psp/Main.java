package com.dam.psp;

import java.util.Random;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int dia;
		int mes;
		System.out.println("Introduce el día que naciste: ");
		dia = scan.nextInt();
		
		System.out.println("Introduce el mes en el que naciste (en número): ");
		mes = scan.nextInt();
		
		if ((dia >= 21 && mes == 3) || (dia <= 20 && mes == 4)) {
            System.out.println("Eres Aries");
        } else if ((dia >= 21 && mes == 4) || (dia <= 20 && mes == 5)) {
            System.out.println("Eres Tauro");
            System.out.println("Tu predicción del día es: ");
            System.out.println(frasesAleatorias()); 
        } else if ((dia >= 21 && mes == 5) || (dia <= 20 && mes == 6)) {
            System.out.println("Eres Géminis");
            System.out.println("Tu predicción del día es: ");
            System.out.println(frasesAleatorias());
        } else if ((dia >= 21 && mes == 6) || (dia <= 22 && mes == 7)) {
            System.out.println("Eres Cáncer");
            System.out.println("Tu predicción del día es: ");
            System.out.println(frasesAleatorias());
        } else if ((dia >= 23 && mes == 7) || (dia <= 22 && mes == 8)) {
            System.out.println("Eres Leo");
            System.out.println("Tu predicción del día es: ");
            System.out.println(frasesAleatorias());
        } else if ((dia >= 23 && mes == 8) || (dia <= 22 && mes == 9)) {
            System.out.println("Eres Virgo");
            System.out.println("Tu predicción del día es: ");
            System.out.println(frasesAleatorias());
        } else if ((dia >= 23 && mes == 9) || (dia <= 22 && mes == 10)) {
            System.out.println("Eres Libra");
            System.out.println("Tu predicción del día es: ");
            System.out.println(frasesAleatorias());
        } else if ((dia >= 23 && mes == 10) || (dia <= 21 && mes == 11)) {
            System.out.println("Eres Escorpio");
            System.out.println("Tu predicción del día es: ");
            System.out.println(frasesAleatorias());
        } else if ((dia >= 22 && mes == 11) || (dia <= 21 && mes == 12)) {
            System.out.println("Eres Sagitario");
            System.out.println("Tu predicción del día es: ");
            System.out.println(frasesAleatorias());
        } else if ((dia >= 22 && mes == 12) || (dia <= 19 && mes == 1)) {
            System.out.println("Eres Capricornio");
            System.out.println("Tu predicción del día es: ");
            System.out.println(frasesAleatorias());
        } else if ((dia >= 20 && mes == 1) || (dia <= 18 && mes == 2)) {
            System.out.println("Eres Acuario");
            System.out.println("Tu predicción del día es: ");
            System.out.println(frasesAleatorias());
        } else if ((dia >= 19 && mes == 2) || (dia <= 20 && mes == 3)) {
            System.out.println("Eres Piscis");
            System.out.println("Tu predicción del día es: ");
            System.out.println(frasesAleatorias());
        } else {
            System.out.println("Fecha no válida");
        }
	}
	public static String frasesAleatorias() {
		String frases[] = {
			"Tienes una serpiente en la bota",
			"Tus padres no te quieren",
			"Hazte pruebas, creo que eres autista",
			"Pusiste el where en el delete from",
			"Eres Swiftie",
			"Te gusta comer rabo de toro",
			"Vas a ser objetivo de un francotirador",
			"Te va a salir bien la semana", 
			"Tienes almorranas",
			"Estas embarazada", 
			"Vas a tener un buen día"
		};
		
		Random random = new Random();
		int numRand = random.nextInt(frases.length);
		return frases[numRand];
		
	}

}


